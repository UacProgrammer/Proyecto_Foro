<!DOCTYPE html >
<html>
<head>
    <nav>
        <div>
            <a href="../index.html">Inicio</a>
            <a href="../dao/foro.php">Foro</a>
            <a href="../dao/ayuda.php">Ayuda</a>
            <a href="" hidden id="Informacion para Admin">Ayuda</a>
        </div>
        <div style="display: inline-block; width: auto; float: right; margin-top: -57px; background-color: transparent;border: transparent;">
        <a href="../dao/login.php" class="btn" id="Log_in_button">Log-in</a> <a href="../dao/registrar.php" class="btn" id="Registrarse_button">Registrarse</a>
        </div>
        <hr style="margin-top: auto; width: 100%;">
    </nav>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <br>
    <br>
    <div style="place-items: center;align-items: center;text-align: left; width: 400px;margin-left: auto;margin-right: auto;">
        <label>Nombre:</label> <input type="text" style="width: 200px;">
        <br>
        <br>
        <label>&nbsp; Correo:</label> <input type="text" style="width: 200px;">
        <br>
        <br>
        <label>Razon:</label>
        <br>
        <textarea style="margin-left: 60px; width: 350px; height: 200px; resize: none;"></textarea>
        <br>
        <br>
        <br>
        <button class="button" style="margin-left: 40%;">Enviar</button>
    </div>
    
</body>
</html>