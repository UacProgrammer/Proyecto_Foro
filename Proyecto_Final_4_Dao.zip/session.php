<?php
	// Manejo de Sesiones en PHP
	class UserSession{

		public $correo;

		public function __construct()
		{
			session_start();
		}
		public function getCorreo($correo){

			

		}
	}
?>
